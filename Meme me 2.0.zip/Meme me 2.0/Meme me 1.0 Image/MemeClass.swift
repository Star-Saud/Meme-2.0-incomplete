//
//  MemeClass.swift
//  Meme me 2.0
//
//  Created by Saud Al-Faleh on 23/05/2019.
//  Copyright © 2019 Saud Al-Faleh. All rights reserved.
//

import UIKit

struct Meme {
    let topText: String
    let bottomText: String
    let originalImage: UIImage
    let memedImage: UIImage
}
