//
//  SentMemeDetail.swift
//  Meme me 2.0
//
//  Created by Saud Al-Faleh on 25/05/2019.
//  Copyright © 2019 Saud Al-Faleh. All rights reserved.
//

import UIKit

class SentMemeDetail: UIViewController {
    
    let meme: Meme
    
    init(meme: Meme) {
        self.meme = meme
        super.init(nibName: nil, bundle: nil)
        view.backgroundColor = .white
        let imageView = UIImageView()
        view.addSubview(imageView)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
