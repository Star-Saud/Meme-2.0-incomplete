//
//  CollectionViewCell.swift
//  Meme me 2.0
//
//  Created by Saud Al-Faleh on 25/05/2019.
//  Copyright © 2019 Saud Al-Faleh. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    var imageView : UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imageView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
